#!/bin/bash
service httpd stop
rm -rf /var/www/html/*