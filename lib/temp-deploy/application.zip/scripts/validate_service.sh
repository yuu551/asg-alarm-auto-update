#!/bin/bash
curl -f http://localhost/